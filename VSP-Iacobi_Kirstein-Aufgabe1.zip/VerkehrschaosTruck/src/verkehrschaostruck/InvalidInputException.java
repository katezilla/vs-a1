package verkehrschaostruck;

public class InvalidInputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6977067420006553934L;

	public InvalidInputException(String s){
		super(s);
	}
}
