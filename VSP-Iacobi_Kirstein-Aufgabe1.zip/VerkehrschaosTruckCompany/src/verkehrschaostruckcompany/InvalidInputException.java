package verkehrschaostruckcompany;

public class InvalidInputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7903778006458279620L;

	public InvalidInputException(String s) {
		super(s);
	}
}
